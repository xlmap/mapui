package com.test.ui ;

import com.test.ui.* ;

public class MapData {

	private int id[] ;
	private int mapWidth = 20 ;
	private int mapHeight = 10 ;
	private int blockWidth = 50 ;
	private int blockHeight = 50 ;
	private long data[][] = {

	
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{1,0,1,0,1,1,1,0,1,0,0,0,1,0,0,0,0,1,0,0},
		{1,0,1,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,1,0},
		{1,0,1,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,1,0},
		{1,1,1,0,1,1,1,0,1,0,0,0,1,0,0,0,1,0,1,0},
		{1,0,1,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,1,0},
		{1,0,1,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,1,0},
		{1,0,1,0,1,1,1,0,1,1,1,0,1,1,1,0,0,1,0,0},
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
	};

	public int getBlockWidth() {
		return this.blockWidth;
	}
	public int getBlockHeight() {
		return this.blockHeight;
	}
	public int getMapWidth() {
		return this.mapWidth;
	}
	public int getMapHeight() {
		return this.blockHeight;
	}
	public long[][] getData() {
		return this.data;
	}

}