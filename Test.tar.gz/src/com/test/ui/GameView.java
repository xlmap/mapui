package com.test.ui;
import android.view.*;
import android.content.*;
import android.util.*;
import android.graphics.*;

public class GameView extends View {

	private Context context;//定义Context对象
	private long data[][]; //绘制游戏地图数据
	private int id[];      //图片资源id数组
	private Paint paint;   //定义画笔用于绘制Bitmap
	private Bitmap bitmap; //定义Bitmap对象

	//地图块的高度和宽度
	private int blockWidth,blockHeight;
	//地图的宽度和高度
	private int mapWidth,mapHeight;
	//屏幕的宽度 高度
	private int screenWidth,screenHeight;


	public GameView(Context context, AttributeSet attr) {
		super(context, attr);
	}

	public GameView(Context context) {
		super(context, null);
		this.context = context;
		WindowManager manager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
		screenWidth = manager.getDefaultDisplay().getWidth();
		screenHeight = manager.getDefaultDisplay().getHeight();
		init();
	}

	//从ResId.java和MapData.java中获得地图参数
	public void init() {
		MapData md = new MapData();
		this.blockWidth = md.getBlockWidth();
		this.blockHeight = md.getBlockHeight();

		this.mapWidth = md.getMapWidth();
		this.mapHeight = md.getMapHeight();
		this.data = md.getData();
		this.id = new ResId().getResId();

		paint = new Paint();
	}

	@Override
	protected void onDraw(Canvas canvas) {
		// TODO: Implement this method
		super.onDraw(canvas);
		//此处应动态绘制地图，提高效率(暂未处理)
		for (int i=0;i < data[0].length;i++) {
			for (int j=0;j < data.length;j++) {
				//此处将data数组的i j位置对调 data[j][i]，不然绘制的地图是反的
				if (data[j][i] != 0) {
					int index = (int)data[j][i] - 1;
					bitmap = BitmapFactory.decodeResource(context.getResources(),id[index]);
					canvas.drawBitmap(bitmap, i * blockWidth, j * blockHeight, paint);
				}
			}
		}
	}

}
