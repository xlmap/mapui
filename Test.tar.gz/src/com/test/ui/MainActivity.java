package com.test.ui;

import android.app.Activity;
import android.widget.TextView;
import android.os.Bundle;

/*
 *此项目为游戏地图测试Dome，由Liuzhiyong所编写
 *您也可以将包名进行更改，作为自己的开发项目
 *工程为ndk，主要是为了方便使用c/c++来开发
 */

public class MainActivity extends Activity {
    /** Called when the activity is first created. */
	public native String  stringFromJNI();

    public native String  unimplementedStringFromJNI();
	
	static {
        System.loadLibrary("hello-jni");
    }
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        super.setContentView(new GameView(this));
    }
    
}
