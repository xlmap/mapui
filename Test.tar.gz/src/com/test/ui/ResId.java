package com.test.ui;

import com.test.ui.*;

public class ResId {

	private int id[] = {
		R.drawable.ic_launcher	};

	public int[] getResId() {
		return this.id ;
	}

}